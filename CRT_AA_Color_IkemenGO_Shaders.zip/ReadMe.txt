Custom IkemenGO CRT, AntiAliasing, ColorCorrection shader pack by airforce111

All paremeters can be adjusted in their respective .frag files.

Tested on IkemenGO .98 and above